# LION AI

A responsive ChatGPT-style AI chat website that works on phones and computers.

## Publish it online with Render

1. Create a GitHub account and a Render account.
2. Upload this project folder to a new GitHub repository.
3. In Render, choose **New + → Blueprint** and connect that GitHub repository.
4. Render reads `render.yaml` and creates the web service.
5. In the Render service settings, add the secret environment variable `OPENAI_API_KEY` with your own OpenAI API key. Keep it private; never put it in `public/` or share it in chat.
6. Deploy. Render provides a public `https://...onrender.com` address that opens on both phone and computer.

`OPENAI_MODEL` is set to `gpt-6-astra` as a starting value. If your API account does not have access to that model, change it in Render's environment settings to a model available to your account, then redeploy.

## Run locally

Requires Node.js 20 or newer:

1. Run `npm install`.
2. Copy `.env.example` to `.env`.
3. Add your OpenAI API key to `.env`.
4. Run `npm start` and visit `http://localhost:3000`.

API usage may incur charges. Before sharing the public site widely, add authentication and rate limiting to prevent unwanted usage. Chat history is stored in each visitor's browser.
